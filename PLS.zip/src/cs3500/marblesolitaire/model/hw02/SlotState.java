//package cs3500.marblesolitaire.model.hw02;
//
//import java.util.Objects;
//
//public enum SlotState {
//  MARBLE("O"),Invalid(" "),Empty("_");
//
//  private final String value;
//
//  private SlotState(String value){
//    this.value = Objects.requireNonNull(value);
//  }
//
//  @Override
//  public String toString(){
//    return this.value;
//  }
//
//}

